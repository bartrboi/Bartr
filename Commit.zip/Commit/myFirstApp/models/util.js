var mongoose = require('mongoose');
var connection = mongoose.connect('mongodb://mongodb3496ma:mu4xuc@danu7.it.nuigalway.ie:8717/mongodb3496');

exports.connection = connection;
